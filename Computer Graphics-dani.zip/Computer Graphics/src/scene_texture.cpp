
#include <iostream>
#include <GL/glew.h>
#include <GL/freeglut.h>
#include <vector>
#include <glm/glm.hpp>
#include <iostream>

#include "InputeFile.h"
#include "Mesh.h"
#include "Shader.h"
#include "ShaderProgram.h"
#include "Transform.h"
#include "Camera.h"
#include <IL/il.h>
#include "Texture2D.h"
#include "Depthbuffer.h"

using namespace std;
using namespace glm;

Mesh mesh;
ShaderProgram program;
ShaderProgram program2;
ShaderProgram program3;

Transform _transform;
Transform _transform2;

Camera _camera;
Camera _camera2;
mat4 modelMatrix;
mat3 normalMatrix;
mat4 modelMatrix2;
mat3 normalMatrix2;
vec3 lightColor = vec3(1.0f, 1.0f, 1.0f);
vec3 lightPosition = vec3(-20.0f, -1.0f, 30.0f);
vec3 lightPosition2 = vec3(0.0f, 20.0f, 0.0f);
Texture2D metal;
Texture2D cerdo;
Texture2D piso;
Depthbuffer depth;

void Initialize() {

	vector<vec3> positions;
	vector<vec3> colors;
	vector<vec3> normals;
	vector<vec2> textures;

	metal.LoadTexture("shaders/metal.jpg");
	piso.LoadTexture("shaders/piso.jpg");
	cerdo.LoadTexture("shaders/cerdito.jpg");

	float x = 7.0f;
	float y = 7.0f;
	float z = 7.0f;

	// Cara frontal
	positions.push_back(vec3(x, -y, z));
	positions.push_back(vec3(x, y, z));
	positions.push_back(vec3(-x, -y, z));
	positions.push_back(vec3(-x, y, z));
	// Cara derecha
	positions.push_back(vec3(x, -y, -z));
	positions.push_back(vec3(x, y, -z));
	positions.push_back(vec3(-x, -y, -z));
	positions.push_back(vec3(-x, y, -z));
	// Cara trasera
	positions.push_back(vec3(x, -y, -z));
	positions.push_back(vec3(x, y, -z));
	positions.push_back(vec3(x, -y, z));
	positions.push_back(vec3(x, y, z));
	// Cara izquierda
	positions.push_back(vec3(-x, -y, -z));
	positions.push_back(vec3(-x, y, -z));
	positions.push_back(vec3(-x, -y, z));
	positions.push_back(vec3(-x, y, z));
	// Cara superior
	positions.push_back(vec3(x, y, z));
	positions.push_back(vec3(x, y, -z));
	positions.push_back(vec3(-x, y, z));
	positions.push_back(vec3(-x, y, -z));
	// Cara inferior
	positions.push_back(vec3(x, -y, z));
	positions.push_back(vec3(x, -y, -z));
	positions.push_back(vec3(-x, -y, z));
	positions.push_back(vec3(-x, -y, -z));



	normals.push_back(vec3(0.0f, 1.0f, 0.0f));
	normals.push_back(vec3(0.0f, 1.0f, 0.0f));
	normals.push_back(vec3(0.0f, 1.0f, 0.0f));
	normals.push_back(vec3(0.0f, 1.0f, 0.0f));

	normals.push_back(vec3(0.0f, 0.0f, 1.0f));
	normals.push_back(vec3(0.0f, 0.0f, 1.0f));
	normals.push_back(vec3(0.0f, 0.0f, 1.0f));
	normals.push_back(vec3(0.0f, 0.0f, 1.0f));

	normals.push_back(vec3(1.0f, 0.0f, 1.0f));
	normals.push_back(vec3(1.0f, 0.0f, 1.0f));
	normals.push_back(vec3(1.0f, 0.0f, 1.0f));
	normals.push_back(vec3(1.0f, 0.0f, 1.0f));

	normals.push_back(vec3(1.0f, 0.0f, 0.0f));
	normals.push_back(vec3(1.0f, 0.0f, 0.0f));
	normals.push_back(vec3(1.0f, 0.0f, 0.0f));
	normals.push_back(vec3(1.0f, 0.0f, 0.0f));

	normals.push_back(vec3(1.0f, 1.0f, 0.0f));
	normals.push_back(vec3(1.0f, 1.0f, 0.0f));
	normals.push_back(vec3(1.0f, 1.0f, 0.0f));
	normals.push_back(vec3(1.0f, 1.0f, 0.0f));

	normals.push_back(vec3(0.0f, 1.0f, 1.0f));
	normals.push_back(vec3(0.0f, 1.0f, 1.0f));
	normals.push_back(vec3(0.0f, 1.0f, 1.0f));
	normals.push_back(vec3(0.0f, 1.0f, 1.0f));


	for (int i = 0; i < 6; i++) {
		textures.push_back(vec2(1.0f, 0.0f));
		textures.push_back(vec2(1.0f, 1.0f));
		textures.push_back(vec2(0.0f, 0.0f));
		textures.push_back(vec2(0.0f, 1.0f));

	}
	vector<unsigned int> indices = { 0, 1, 2, 2, 1, 3, 4, 5, 6, 6, 5, 7, 8, 9, 10, 10, 9, 11, 12, 13, 14, 14, 13, 15,16, 17, 18, 18, 17, 19, 20,21,22,22,21,23, };

	mesh.CreateMesh(24);
	mesh.SetPositionAttribute(positions, GL_STATIC_DRAW, 0);
	mesh.SetColorAttribute(colors, GL_STATIC_DRAW, 1);
	mesh.SetNormalAttribute(normals, GL_STATIC_DRAW, 2);
	mesh.SetTexCoordAttribute(textures, GL_STATIC_DRAW, 3);
	mesh.SetIndices(indices, GL_STATIC_DRAW);
	glBindVertexArray(0);

	program2.CreateProgram();

	program3.CreateProgram();
	program3.AttachShader("shaders/Shadow.vert", GL_VERTEX_SHADER);
	program3.AttachShader("shaders/Shadow.frag", GL_FRAGMENT_SHADER);
	program3.SetAttribute(0, "VertexPosition");
	program3.SetAttribute(1, "VertexColor");
	program3.SetAttribute(2, "VertexNormal");
	program3.SetAttribute(3, "VertexTexCoord");
	program3.LinkProgram();

	program3.Activate();
	program3.SetUniformf("LightColor", 1.0f, 1.0f, 1.0f);
	program3.SetUniformf("LightPosition", lightPosition2.x, lightPosition2.y, lightPosition2.z);
	program3.SetUniformf("CameraPosition", _camera.GetPosition().x, _camera.GetPosition().y, _camera.GetPosition().z);
	program3.SetUniformi("DiffuseTexture", 0);
	program3.SetUniformi("DiffuseTexture2", 1);
	program3.SetUniformi("ShadowMap", 2);

	program3.Deactivate();

	program.CreateProgram();
	program.AttachShader("shaders/Shadow2.vert", GL_VERTEX_SHADER);
	program.AttachShader("shaders/Shadow2.frag", GL_FRAGMENT_SHADER);
	program.SetAttribute(0, "VertexPosition");
	program.SetAttribute(1, "VertexColor");
	program.SetAttribute(2, "VertexNormal");
	program.SetAttribute(3, "VertexTexCoord");
	program.LinkProgram();

	program.Activate();
	program.SetUniformf("LightColor", 1.0f, 1.0f, 1.0f);
	program.SetUniformf("LightPosition", lightPosition2.x, lightPosition2.y, lightPosition2.z);
	program.SetUniformf("CameraPosition", _camera.GetPosition().x, _camera.GetPosition().y, _camera.GetPosition().z);
	program.SetUniformi("DiffuseTexture", 0);
	program.SetUniformi("DiffuseTexture2", 1);
	program.SetUniformi("ShadowMap", 2);
	program.Deactivate();

	_camera.SetPosition(0.0f, 20.0f, 60.0f);
	_camera2.SetPosition(lightPosition2.x, lightPosition2.y, lightPosition2.z);
	_camera2.Pitch(-90);
	_camera.Pitch(-20);
	_camera2.SetOrthographic(180.0f, 1.0f);
	_transform.SetRotation(-50.0f, 0.0f, 0.0f);
	_transform2.SetScale(15.0f, 1.0f, 25.0f);
	_transform2.SetPosition(0.0f, -30.0f, 0.0f);


	depth.Create(2048);
}

void GameLoop() {
	_transform.Rotate(0.03f, 0.03f, 0.03f, true);
	depth.Bind();
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	//Cubito
	program2.Activate();
	program2.SetUniformMatrix("mvpMatrix", _camera2.GetViewProjection() * _transform.GetModelMatrix());
	mesh.Draw(GL_TRIANGLES);

	program2.Deactivate();
	depth.Unbind();

	//glViewport(0, 0, 450, 450); 
	glViewport(0, 0, glutGet(GLUT_WINDOW_WIDTH), glutGet(GLUT_WINDOW_HEIGHT)); //Esto hace que cuando se maximice la pantalla el cubo igual
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	program.Activate();
	glActiveTexture(GL_TEXTURE0);
	metal.Bind();
	glActiveTexture(GL_TEXTURE1);
	cerdo.Bind();
	glActiveTexture(GL_TEXTURE2);
	depth.BindDepthMap();
	modelMatrix = _transform.GetModelMatrix();
	normalMatrix = transpose(inverse(mat3(_transform.GetModelMatrix())));
	program.SetUniformMatrix("modelMatrix", modelMatrix);
	program.SetUniformMatrix3("normalMatrix", normalMatrix);
	program.SetUniformMatrix("mvpMatrix", _camera.GetViewProjection()* _transform.GetModelMatrix());
	program.SetUniformMatrix("LightVPMatrix", _camera2.GetViewProjection());
	mesh.Draw(GL_TRIANGLES);
	glActiveTexture(GL_TEXTURE0);
	metal.Unbind();
	glActiveTexture(GL_TEXTURE1);
	cerdo.Unbind();
	glActiveTexture(GL_TEXTURE2);
	depth.UnbindDepthMap();
	program.Deactivate();

	program3.Activate();
	glActiveTexture(GL_TEXTURE0);
	piso.Bind();
	glActiveTexture(GL_TEXTURE2);
	depth.BindDepthMap();
	modelMatrix2 = _transform2.GetModelMatrix();
	normalMatrix2 = transpose(inverse(mat3(_transform2.GetModelMatrix())));
	program3.SetUniformMatrix("modelMatrix", modelMatrix2);
	program3.SetUniformMatrix3("normalMatrix", normalMatrix2);
	program3.SetUniformMatrix("mvpMatrix", _camera.GetViewProjection()* _transform2.GetModelMatrix());
	program3.SetUniformMatrix("LightVPMatrix", _camera2.GetViewProjection());
	mesh.Draw(GL_TRIANGLES);
	glActiveTexture(GL_TEXTURE0);
	piso.Unbind();
	glActiveTexture(GL_TEXTURE2);
	depth.UnbindDepthMap();
	program3.Deactivate();

	glutSwapBuffers();

}

void Idle() {
	//cuando entra en estado de reposo se vuelve a dibujar
	glutPostRedisplay();
}

void ReshapeWindow(int w, int h) {
	glViewport(0, 0, w, h);

}

int main(int argc, char* argv[]) {
	// Inicializar freeglut
	// Freeglut se encargfa de crear una ventana en donde podemos dibujar Gr�ficas Computacionales
	glutInit(&argc, argv);
	glutInitContextVersion(4, 2);


	// Iniciar el contexto de OpenGL, se refiere a las capacidades de la aplicaci�n gr�fica
	// En este caso se trabaja con el pipeline progamable
	glutInitContextProfile(GLUT_CORE_PROFILE);

	// Freeglut nos permite configurar eventos que ocurren en la ventana
	// Un evento que interesa es cuando alguien cierra la ventana
	// En este caso, se deja de renderear la escena y se termina el programa
	glutSetOption(GLUT_ACTION_ON_WINDOW_CLOSE, GLUT_ACTION_GLUTMAINLOOP_RETURNS);

	// Tambi�n configuramos frambuffer, en este caso solicitamos un buffer
	// true color RGBA, un buffer de produndidad y un segundo buffer para renderear
	glutInitDisplayMode(GLUT_RGBA | GLUT_DEPTH | GLUT_DOUBLE); // Dos framebuffers

	// Iniciar las dimensiones de la ventana (en pixeles)
	glutInitWindowSize(450, 450);

	// Creeamos la ventana y le damos un t�tulo.
	glutCreateWindow("Cubito con dos sombras");

	glutDisplayFunc(GameLoop);
	//asociamos una funci�n ara el cambio de resolucion de la ventana.
	//freeglut la va a mandar a llamar
	//cuando alguien cambie el tama�o de la ventana
	glutReshapeFunc(ReshapeWindow);

	//asociamos la funci�n cuando openGL entra en estado de reposos
	glutIdleFunc(Idle);
	// Inicializamos GLEW. Esta librer�a se encarga de obtener el API de OpenGL de nuestra tarjeta de video
	glewInit();
	//glClearColor(1.0f, 1.0f, 1.0f, 1.0f);

	glEnable(GL_DEPTH_TEST);
	std::cout << glGetString(GL_VERSION) << std::endl;
	glClearColor(1.0f, 1.0f, 0.5f, 1.0f); //AMARILLO


	ilInit();
	//Queremos cambiar el punto de origen
	ilEnable(IL_ORIGIN_SET);
	//Configuramos el origen de las texturas generadas por devil como abajo a la izquierda
	ilOriginFunc(IL_ORIGIN_LOWER_LEFT);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	// Configuraci�n inicial de nuestro programa
	Initialize();
	// Iniciar la aplicaci�n. El Main se pausar� en esta l�nea hasta que se cierre la ventana.
	glutMainLoop();

	return 0;
}

